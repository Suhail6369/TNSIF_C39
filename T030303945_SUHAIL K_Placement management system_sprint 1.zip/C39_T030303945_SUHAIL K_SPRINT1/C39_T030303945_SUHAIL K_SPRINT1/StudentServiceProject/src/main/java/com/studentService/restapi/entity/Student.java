package com.studentService.restapi.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity 
@Table(name = "student") 
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int rollno;
	@Column(name = "student_name")
	private String name;
	@Column(name = "student_initial")
	private String initial;
	@Column(name = "student_email")
	private String email;
	@Column(name = "student_DOB")
	private String DOB;
	@Column(name = "student_Department")
	private String Department;
	public Student() {
		
	}
	
	public Student(String name, String initial, String email, String dOB, String department) {
		super();
		this.name = name;
		this.initial = initial;
		this.email = email;
		DOB = dOB;
		Department = department;
	}

	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getInitial() {
		return initial;
	}
	public void setInitial(String initial) {
		this.initial = initial;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public String getDepartment() {
		return Department;
	}
	public void setDepartment(String department) {
		Department = department;
	}
	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", name=" + name + ", initial=" + initial + ", email=" + email + ", DOB="
				+ DOB + ", Department=" + Department + "]";
	}
	
}
