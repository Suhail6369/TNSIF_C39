package com.studentService.restapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentServiceProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
