package com.assignment3;

public interface Airfare {
	double calculateAmount();
    void display();

}

